package com.misiontic2022.reto5.model;

/**
 * Bodega Modelo
 * @author Cristian
 * @author Laura
 */
public class Bodega {
    private int idbodega;
    private String nombre;
    private int cantidadpisos;

    /**
     * Constructor por defecto
     */
    public Bodega() {
        idbodega = 0;
        nombre = null;
        cantidadpisos = 0;
    }

    /**
     * Constructor con parametros
     * @param idbodega identificador de bodega
     * @param nombre nombre de bodega
     * @param cantidadpisos cantidad de pisos de bodega
     */
    public Bodega(int idbodega, String nombre, int cantidadpisos) {
        this.idbodega = idbodega;
        this.nombre = nombre;
        this.cantidadpisos = cantidadpisos;
    }

    /**
     * retorna el id de bodega
     * @return id de bodega
     */
    public int getIdbodega() {
        return idbodega;
    }

    /**
     * sobreescribe id de bodega
     * @param idbodega id de bodega
     */
    public void setIdbodega(int idbodega) {
        this.idbodega = idbodega;
    }

    /**
     * retorna el nombre de bodega
     * @return nombre de bodega
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * sobreescribe el nombre de bodega
     * @param nombre nombre de bodega
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * retorna cantidad de pisos de bodega
     * @return cantidad de pisos de bodega
     */
    public int getCantidadpisos() {
        return cantidadpisos;
    }

    /**
     * sobreescribe cantidad de pisos
     * @param cantidadpisos cantidad de pisos de bodega
     */
    public void setCantidadpisos(int cantidadpisos) {
        this.cantidadpisos = cantidadpisos;
    }

    /**
     * Sobre escribe el meotodo toString de bodega.
     * @return String con informacion de bodega
     */
    @Override
    public String toString() {
        return idbodega + " - " +nombre ;
    }
}
