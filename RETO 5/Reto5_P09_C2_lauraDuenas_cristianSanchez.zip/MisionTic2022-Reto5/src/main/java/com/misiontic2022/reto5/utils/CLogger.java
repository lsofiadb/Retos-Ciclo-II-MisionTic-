package com.misiontic2022.reto5.utils;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * @author Cristian
 * @author Laura
 */
public class CLogger {
    private static final Logger LOG = Logger.getLogger("main-log");

    public static void log(Level level, String msg) {
        LOG.log(level, msg);
    }
    public static void logErr( String msg) {
        LOG.log(Level.SEVERE, msg);
    }
    public static void logInfo(String msg) {
        LOG.log(Level.INFO, msg);
    }
    public static void logWarn(String msg) {
        LOG.log(Level.WARNING, msg);
    }
}
