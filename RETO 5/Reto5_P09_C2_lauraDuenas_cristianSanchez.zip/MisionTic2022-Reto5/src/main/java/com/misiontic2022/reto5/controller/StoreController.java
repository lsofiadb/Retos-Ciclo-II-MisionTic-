package com.misiontic2022.reto5.controller;

import com.misiontic2022.reto5.dao.AlmacenarDAO;
import com.misiontic2022.reto5.dao.BodegaDAO;
import com.misiontic2022.reto5.dao.CategoriaDAO;
import com.misiontic2022.reto5.dao.SuministroDAO;
import com.misiontic2022.reto5.model.Bodega;
import com.misiontic2022.reto5.model.Categoria;
import com.misiontic2022.reto5.model.Suministro;

import java.util.List;

public class StoreController {

    /**
     * Obtiene un array <code>Bodega[]</code> con todas las bodegas registradas en BD.
     * @return lista de todas las bodegas registradas.
     */
    public static Bodega[] obtenerBodegas() {
        return new BodegaDAO().obtenerBodegas().toArray(Bodega[]::new);
    }

    /**
     * Obtiene el numero total de productos de una bodega en especifico.
     * @param bodega la bodega en la cual se va a contar los productos
     * @return un numero entero, con el numero total de productos.
     */
    public static int obtenerTotalProductos(Bodega bodega){
        return new AlmacenarDAO().obtenerNumeroProductos(bodega);
    }

    /**
     * Obtiene todos los suministros que se encuentran en una bodega en específico.
     * @param bodega Bodega donde se va a buscar los suministros.
     * @return una lista de suministros.
     */
    public static List<Suministro> obtenerSuministrosBodega(Bodega bodega){
        return new AlmacenarDAO().obtenerSuministrosBodega(bodega);
    }

    /**
     * Obtiene todos los suministros almacenados en BD
     * @return Una lista con todos los suministros de la BD.
     */
    public static List<Suministro> obtenerTodosSuministros() {
        return new SuministroDAO().obtenerSuministros();
    }

    /**
     * Obtiene todas la categorias de la base de datos
     * @return Una lista con todas las categorias del sistema.
     */
    public static List<Categoria> obtenerTodoCategoria() {
        return new CategoriaDAO().obtenerCategorias();
    }

    /**
     * Agrega un suministro a la tabla suministros.
     * @param nombre Nombre del suministro a ingresar
     * @param precio Precio del suministro a ingresar
     * @param categoria Categoria del suministro a ingresar.
     */
    public static void insertNewInsumo(String nombre, float precio, Categoria categoria) {
        new SuministroDAO().insertSuministro(new Suministro(categoria, nombre, precio));
    }

    /**
     * Agrega un suministro nuevo a la bodega especifica
     * @param bodega bodega a la cual se va a ingresar el suministro
     * @param suministro suministro a ingresar a bodega.
     */
    public static void newRegistro(Bodega bodega, Suministro suministro) {
        new AlmacenarDAO().insertarRegistro(suministro, bodega);
    }

    /**
     * Obtener el ultimo suministro que se ingreso a la base de datos
     * @return SUltimo suministro en la BD.
     */
    public static Suministro obtenerUltimoSuministro() {
        return new SuministroDAO().obtenerUltimoSuministro();
    }

    /**
     * Elimina registro de suministro en una bodega
     * @param suministro el suministro a eliminar.
     * @param bodega la bodega donde se va a eliminar el suministro
     */
    public static void deleteRegistro(Suministro suministro,Bodega bodega){
        new AlmacenarDAO().eliminarSuministro(suministro,bodega);
    }

    /**
     * Actualiza los datos de una bodega.
     * @param bodega bodega a actualizar.
     */
    public static void updateBodega(Bodega bodega) {
        new BodegaDAO().update(bodega);
    }
}
