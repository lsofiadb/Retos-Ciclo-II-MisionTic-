package com.misiontic2022.reto5.view;

import com.misiontic2022.reto5.controller.StoreController;
import com.misiontic2022.reto5.model.Suministro;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Iterator;
import java.util.List;
import javax.swing.*;

import static javax.swing.WindowConstants.EXIT_ON_CLOSE;


/**
 * @author Cristian
 * @author Laura
 */
public class DialogAgregarSuministro extends JDialog {
    //atributos
    JLabel lblEliminar, lblId;
    JComboBox<Suministro> cmbSuministro;
    JButton btnEliminar;

    //Constructor
    public DialogAgregarSuministro(ActionListener listener) {
        this.setModal(true);
        this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        this.setLayout(null);
        this.getContentPane().setBackground(new Color(204, 209, 209));
        this.setBounds(0, 0, 400, 280);
        this.setLocationRelativeTo(null);
        this.setResizable(false);

        crearComponentes(listener);
        updateComboBox();
        this.setVisible(false);
    }

    public void open(){
        updateComboBox();
        this.setVisible(true);
    }

    private void updateComboBox() {
        cmbSuministro.removeAllItems();
        for (Suministro suministro : StoreController.obtenerTodosSuministros()) {
            cmbSuministro.addItem(suministro);
        }
    }

    public void crearComponentes(ActionListener listener){
        lblEliminar= new JLabel("Seleccionar Suministro");
        lblEliminar.setBounds(60, 10, 270, 30);
        lblEliminar.setForeground(Color.BLACK);
        lblEliminar.setFont(new Font("Times New Roman",1,25));
        add(lblEliminar);

        lblId= new JLabel("Suministro:");
        lblId.setBounds(20, 90, 220, 30);
        lblId.setForeground(Color.BLACK);
        lblId.setFont(new Font("Times New Roman",1,25));
        add(lblId);

        cmbSuministro= new JComboBox<>();
        cmbSuministro.setBounds(200, 90, 150, 30);
        cmbSuministro.setForeground(Color.BLACK);
        cmbSuministro.setFont(new Font("Times New Roman",1,15));
        add(cmbSuministro);

        btnEliminar=new JButton("Agregar");
        btnEliminar.setBounds(85, 170, 220, 30);
        btnEliminar.setForeground(Color.BLACK);
        btnEliminar.setBackground(new Color(130, 224, 170));
        btnEliminar.setFont(new Font("Times New Roman",1,20));
        btnEliminar.addActionListener(listener);
        btnEliminar.setActionCommand("ExisSum");
        add(btnEliminar);

    }

    public Suministro getSuministro() {
        return (Suministro) cmbSuministro.getSelectedItem();
    }

    public void close(){
        cmbSuministro.setSelectedIndex(0);
        this.dispose();
    }
}
