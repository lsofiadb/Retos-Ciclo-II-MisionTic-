package com.misiontic2022.reto5.view;

import com.misiontic2022.reto5.model.Bodega;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

import static javax.swing.WindowConstants.EXIT_ON_CLOSE;


/**
 * @author Cristian
 * @author Laura
 */
public class DialogModificarBodega extends JDialog {
    //atributos 
    JLabel lblModificar, lblNombre, lblPisos;
    JTextField tNombre, tPisos;
    JButton btnModificar;

    //Constructor 
    public DialogModificarBodega(Bodega bodega, ActionListener listener) {
        this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        this.setModal(true);
        this.setLayout(null);
        this.getContentPane().setBackground(new Color(204, 209, 209));
        this.setBounds(0, 0, 400, 300);
        this.setLocationRelativeTo(null);
        this.setResizable(false);

        crearComponentes(bodega, listener);
        this.setVisible(false);
    }

    public void crearComponentes(Bodega bodega, ActionListener listener) {
        lblModificar = new JLabel("Modificar Bodega");
        lblModificar.setBounds(85, 10, 230, 30);
        lblModificar.setForeground(Color.BLACK);
        lblModificar.setFont(new Font("Times New Roman", 1, 25));
        add(lblModificar);

        lblNombre = new JLabel("Nombre:");
        lblNombre.setBounds(20, 65, 150, 30);
        lblNombre.setForeground(Color.BLACK);
        lblNombre.setFont(new Font("Times New Roman", 1, 25));
        add(lblNombre);

        tNombre = new JTextField();
        tNombre.setBounds(200, 65, 150, 30);
        tNombre.setForeground(Color.BLACK);
        tNombre.setFont(new Font("Times New Roman", 1, 25));
        tNombre.setText(bodega.getNombre());
        add(tNombre);

        lblPisos = new JLabel("Cantidad Pisos:");
        lblPisos.setBounds(20, 115, 220, 30);
        lblPisos.setForeground(Color.BLACK);
        lblPisos.setFont(new Font("Times New Roman", 1, 25));
        add(lblPisos);

        tPisos = new JTextField();
        tPisos.setBounds(200, 115, 150, 30);
        tPisos.setForeground(Color.BLACK);
        tPisos.setFont(new Font("Times New Roman", 1, 25));
        add(tPisos);
        tPisos.setText(bodega.getCantidadpisos() + "");

        btnModificar = new JButton("Modificar");
        btnModificar.setBounds(85, 185, 220, 30);
        btnModificar.setForeground(Color.BLACK);
        btnModificar.setBackground(new Color(130, 224, 170));
        btnModificar.setFont(new Font("Times New Roman", 1, 20));
        btnModificar.addActionListener(listener);
        btnModificar.setActionCommand("editBod");
        add(btnModificar);

    }

    public void close() {
        this.dispose();
    }

    public int getDataNumeroP() {
        if (tPisos.getText().length() > 0 && tPisos.getText().matches("^[\\d]+$"))
            return Integer.parseInt(tPisos.getText());
        else
            JOptionPane.showMessageDialog(this, "Campo de pisos vacio o no es numero", "Error", JOptionPane.ERROR_MESSAGE);
        return -1;
    }

    public String getDataNombre() {
        if (tNombre.getText().length() > 0)
            return tNombre.getText();
        else
            JOptionPane.showMessageDialog(this, "Campo de pisos vacio o no es numero", "Error", JOptionPane.ERROR_MESSAGE);
        return null;
    }
}
