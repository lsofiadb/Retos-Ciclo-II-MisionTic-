package com.misiontic2022.reto5.view;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JTextField;


/**
 * @author Cristian
 * @author Laura
 */
public class DialogSelectAgregar extends JDialog {
    //atributos
    JLabel lblSelect;
    JButton btnNew, btnExistent;

    //Constructor
    public DialogSelectAgregar(ActionListener listener){
        this.setTitle("Agregar Suministro");
        this.setModal(true);
        this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        this.setLayout(null);
        this.getContentPane().setBackground(new Color(204, 209, 209));
        this.setBounds(0, 0, 550, 200);
        this.setLocationRelativeTo(null);
        this.setResizable(false);

        crearComponentes(listener);
        this.setVisible(false);
    }

    public void crearComponentes(ActionListener listener) {
        lblSelect = new JLabel("Seleccione una opcion");
        lblSelect.setBounds(150, 10,
                350, 30);
        lblSelect.setForeground(Color.BLACK);
        lblSelect.setFont(new Font("Times New Roman", 1, 25));
        add(lblSelect);


        btnNew = new JButton("Suministro Nuevo");
        btnNew.setBounds(10, 80, 250, 50);
        btnNew.setForeground(Color.BLACK);
        btnNew.setBackground(new Color(130, 224, 170));
        btnNew.setFont(new Font("Times New Roman", 1, 20));
        btnNew.addActionListener(listener);
        btnNew.setActionCommand("new");
        add(btnNew);

        btnExistent = new JButton("Suministro Existente");
        btnExistent.setBounds(270 , 80, 250, 50);
        btnExistent.setForeground(Color.BLACK);
        btnExistent.setBackground(new Color(130, 224, 170));
        btnExistent.setFont(new Font("Times New Roman", 1, 20));
        btnExistent.addActionListener(listener);
        btnExistent.setActionCommand("exist");
        add(btnExistent);


    }

    public void close(){
        this.dispose();
    }
}
