package com.misiontic2022.reto5.model;


/**
 * Clase POJO SUministro
 * @author Cristian
 * @author Laura
 */
public class Suministro {
    //atributos
    private int idSuministro;
    private Categoria categoria;
    private String nombre;
    private float precio;
    
    //constructor 1
    public Suministro() {
        idSuministro = 0;
        categoria = null;
        nombre = null;
        precio = 0;
    }

    public Suministro(int idSuministro) {
        this.idSuministro = idSuministro;
    }

    //constructor 2 (Sobrecarga de metodos)
    public Suministro(int idSuministro, Categoria categoria, String nombre, float precio) {
        this.idSuministro = idSuministro;
        this.categoria = categoria;
        this.nombre = nombre;
        this.precio = precio;
        
    }

    public Suministro(Categoria categoria, String nombre, float precio){
        this.categoria = categoria;
        this.nombre = nombre;
        this.precio = precio;
    }
    
    //getters and setters 
    public int getIdSuministro() {
        return idSuministro;
    }

    public void setIdSuministro(int idSuministro) {
        this.idSuministro = idSuministro;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    public void setCategoria(Categoria categoria) {
        this.categoria = categoria;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public float getPrecio() {
        return precio;
    }

    public void setPrecio(float precio) {
        this.precio = precio;
    }

    public String toString() {
        return idSuministro +" - "+nombre;
    }
}
