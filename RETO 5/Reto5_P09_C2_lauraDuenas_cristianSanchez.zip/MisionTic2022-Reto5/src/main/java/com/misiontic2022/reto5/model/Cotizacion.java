package com.misiontic2022.reto5.model;

import java.time.LocalDateTime;


/**
 * Clase POJO cotizacion
 * @author Cristian
 * @author Laura
 */
public class Cotizacion {
    private int idCotizacion;
    private LocalDateTime fecha;
    private Suministro suministro;
    private Proveedor proveedor;

    public Cotizacion() {
        idCotizacion = 0;
        fecha = LocalDateTime.now();
        suministro = null;
        proveedor = null;

    }

    public Cotizacion(int idCotizacion, LocalDateTime fecha, Suministro suministros, Proveedor proveedor) {
        this.idCotizacion = idCotizacion;
        this.fecha = fecha;
        this.suministro = suministros;
        this.proveedor = proveedor;
    }

    public int getIdCotizacion() {
        return idCotizacion;
    }

    public void setIdCotizacion(int idCotizacion) {
        this.idCotizacion = idCotizacion;
    }

    public LocalDateTime getFecha() {
        return fecha;
    }

    public void setFecha(LocalDateTime fecha) {
        this.fecha = fecha;
    }

    public Suministro getSuministros() {
        return suministro;
    }

    public void setSuministro(Suministro suministro) {
        this.suministro = suministro;
    }

    public Proveedor getProveedor() {
        return proveedor;
    }

    public void setProveedor(Proveedor proveedor) {
        this.proveedor = proveedor;
    }
}
