package com.misiontic2022.reto5.model;

import javax.swing.*;

/**
 * Modelo Almacenar
 * @author Cristian
 * @author Laura
 */
public class Almacenar {
    private int idAlmacen;
    private Suministro suministro;
    private Bodega bodegas;

    /**
     * Constructor por defecto
     */
    public Almacenar() {
        idAlmacen = 0;
        suministro = null;
        bodegas = null;
    }

    /**
     * Constructor con Suministro y bodega
     * @param suministro suministro para registrar
     * @param bodega bodega para registrar
     */
    public Almacenar(Suministro suministro, Bodega bodega) {
        this.suministro = suministro;
        this.bodegas = bodega;
    }

    /**
     *Returns Id de almacen
     * @return id de almacen
     */
    public int getIdAlmacen() {
        return idAlmacen;
    }

    /**
     * Sobreescribe el valor id de almacen
     * @param idAlmacen id de almacen para sobreescribir
     */
    public void setIdAlmacen(int idAlmacen) {
        this.idAlmacen = idAlmacen;
    }

    /**
     * retorna suministro
     * @return <code>Suministro</code> que esta en registro
     */
    public Suministro getSuministro() {
        return suministro;
    }

    /**
     * Sobreescribe información de suministro.
     * @param suministro informacion para sobreescribir
     */
    public void setSuministro(Suministro suministro) {
        this.suministro = suministro;
    }

    /**
     * returns bodega object
     * @return bodega object
     */
    public Bodega getBodegas() {
        return bodegas;
    }

    /**
     * Sobreescribe informacion de bodega
     * @param bodegas informacion de bodega.
     */
    public void setBodegas(Bodega bodegas) {
        this.bodegas = bodegas;
    }
}
