package com.misiontic2022.reto5.daoi;

import com.misiontic2022.reto5.model.Bodega;

import java.util.List;

/**
 * Interface de <code>BodegaDAO</code>
 * @author Laura
 * @author Cristian
 */
public interface IBodegaDAO {
    /**
     * Obtener todas las bodegas del sistema
     * @return lista de bodegas
     */
    List<Bodega> obtenerBodegas();

    /**
     * Actualiza informacion de bodega
     * @param bodega bodega donde se actualizaran datos
     */
    void update(Bodega bodega);
}
