package com.misiontic2022.reto5.dao;

import com.misiontic2022.reto5.connection.ConnectionMySQL;
import com.misiontic2022.reto5.daoi.IAlmacenarDAO;
import com.misiontic2022.reto5.model.Bodega;
import com.misiontic2022.reto5.model.Categoria;
import com.misiontic2022.reto5.model.Suministro;
import com.misiontic2022.reto5.utils.CLogger;

import javax.swing.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Crud tabla Almacenar
 * @author Laura
 * @author Cristian
 */
public class AlmacenarDAO implements IAlmacenarDAO {

    /**
     * Obtiene suministros de una bodega en especifico
     * @param bodega bodega donde buscar suministros
     * @return Lista de suministros en la bodega
     */
    @Override
    public ArrayList<Suministro> obtenerSuministrosBodega(Bodega bodega) {
        ArrayList<Suministro> suministros = new ArrayList();
        Connection conn = null;
        try {
            conn = ConnectionMySQL.getConnection();
            String sql = "select s.idsuministro, s.nombre,c.idcategoria, c.nombre, s.precio  from suministro s, almacenar a, bodega b, categoria c "
                    + "where s.idsuministro=a.idsuministro and "
                    + "s.idcategoria=c.idcategoria and "
                    + "a.idbodega=b.idbodega and "
                    + "b.nombre = ? ORDER BY s.idsuministro;";
            Suministro suministro;
            Categoria categoria;
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setString(1, bodega.getNombre());
            ResultSet result = statement.executeQuery();

            while (result.next()) {
                categoria = new Categoria(result.getInt(3), result.getString(4));
                suministro = new Suministro(result.getInt(1), categoria, result.getString(2), result.getFloat(5));
                suministros.add(suministro);
            }

        } catch (SQLException ex) {
            Logger.getLogger(AlmacenarDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        return suministros;
    }

    /**
     * Se añaden suministros a una bodega en especifico.
     * @param suministro el suministro a ingresar
     * @param bodega bodega donde se va a ingresar el suministro
     */
    @Override
    public void insertarRegistro(Suministro suministro, Bodega bodega) {
        Connection conn = null;
        try {
            conn = ConnectionMySQL.getConnection();
            String sql = "insert into almacenar (idsuministro,idbodega) VALUES (?, ?) ;";
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setInt(1, suministro.getIdSuministro());
            statement.setInt(2, bodega.getIdbodega());

            int rowsUpdated = statement.executeUpdate();

            if (rowsUpdated > 0) {
                JOptionPane.showMessageDialog(null, "Registro almacenado con éxito en tabla Almacenar");
            }
        } catch (SQLException ex) {
            Logger.getLogger(AlmacenarDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    /**
     * Se eliminan los suministros de una bodega por ID
     * @param suministro suministro a eliminar
     * @param bodega bodega donde se va a eliminar el suministro
     */
    @Override
    public void eliminarSuministro(Suministro suministro, Bodega bodega) {
        Connection conn = null;
        try {
            conn = ConnectionMySQL.getConnection();
            String sql = "delete from almacenar a where a.idsuministro =? and a.idbodega = ?;";
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setInt(1, suministro.getIdSuministro());
            statement.setInt(2, bodega.getIdbodega());
            int rowsDeleted = statement.executeUpdate();

            if (rowsDeleted > 0) {
                JOptionPane.showMessageDialog(null, "Suministro eliminado exitosamente");
            } else {
                JOptionPane.showMessageDialog(null, "No se encontro el suministro");
            }

        } catch (SQLException ex) {
            Logger.getLogger(AlmacenarDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    /**
     * Obtiene la cantidad total de productos de una bodega
     * @param bodega donde se contara los productos
     * @return el numero total de productos de una bodega
     */
    @Override
    public int obtenerNumeroProductos(Bodega bodega) {
        int total = 0;
        try {
            Connection conn = ConnectionMySQL.getConnection();
            String sql = "select COUNT(*) from almacenar where idbodega = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, bodega.getIdbodega());
            ResultSet rs = stmt.executeQuery();
            rs.next();
            total = rs.getInt(1);
        } catch (SQLException e) {
            CLogger.logErr(e.getMessage());
        }
        return total;
    }

}
