package com.misiontic2022.reto5.dao;

import com.misiontic2022.reto5.connection.ConnectionMySQL;
import com.misiontic2022.reto5.daoi.IBodegaDAO;
import com.misiontic2022.reto5.model.Bodega;
import com.misiontic2022.reto5.utils.CLogger;

import javax.swing.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Crud tabla Bodega
 * @author Laura
 * @author Cristian
 */
public class BodegaDAO implements IBodegaDAO {

    /**
     * Obtiene todas las bodegas que hay en el sistema
     * @return lista de bodegas de la base de datos
     */
    @Override
    public List<Bodega> obtenerBodegas() {
        List<Bodega> bodegas = new ArrayList<>();
        try {
            Connection conn = ConnectionMySQL.getConnection();
            String sql = "select * from bodega;";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                bodegas.add(new Bodega(
                        rs.getInt("idbodega"),
                        rs.getString("nombre"),
                        rs.getInt("cantidadpisos")
                ));
            }
        } catch (SQLException e) {
            CLogger.logErr(e.getMessage());
        }
        return bodegas;
    }

    /**
     * Actualiza los datos de una bodega
     * @param bodega bodega la cual se actualizará.
     */
    @Override
    public void update(Bodega bodega) {
        Connection conn = null;
        try {
            conn = ConnectionMySQL.getConnection();
            String sql = "update bodega set nombre = ?,cantidadpisos = ? where idbodega = ?;";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(2,bodega.getCantidadpisos());
            stmt.setInt(3,bodega.getIdbodega());
            stmt.setString(1,bodega.getNombre());
            int row = stmt.executeUpdate();

            if (row > 0) {
                JOptionPane.showMessageDialog(null, "Datos de Bodega Actualizados");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            CLogger.logErr(e.getMessage());
        }

    }
}
