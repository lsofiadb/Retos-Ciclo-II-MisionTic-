package com.misiontic2022.reto5.dao;

import com.misiontic2022.reto5.connection.ConnectionMySQL;
import com.misiontic2022.reto5.daoi.ISuministroDAO;
import com.misiontic2022.reto5.model.Categoria;
import com.misiontic2022.reto5.model.Suministro;
import com.misiontic2022.reto5.utils.CLogger;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 * Crud tabla Suministro
 * @author Laura
 * @author Cristian
 */
public class SuministroDAO implements ISuministroDAO {

    /**
     * Se actualiza la informacion de un suministro
     * @param suministro suministro a actualizar.
     */
    @Override
    public void actualizarSuministro(Suministro suministro) {
        Connection conn = null;
        try {
            conn = ConnectionMySQL.getConnection();
            String sql = "update suministro s "
                    + " set s.nombre = ?, s.precio = ?, s.idcategoria = ? "
                    + " where  s.idsuministro =  ?";

            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setString(1, suministro.getNombre());
            statement.setFloat(2, suministro.getPrecio());
            statement.setInt(3, suministro.getCategoria().getIdCategoria());
            statement.setInt(4, suministro.getIdSuministro());

            int rowsUpdated = statement.executeUpdate();

            if (rowsUpdated > 0) {
                JOptionPane.showMessageDialog(null, "Suministro actualizado exitosamente");
            }

        } catch (SQLException ex) {
            CLogger.logErr(ex.getMessage());
        }


    }

    /**
     * Se obtiene todos los suministros de la tabla.
     * @return Lista con todos los suministros.
     */
    @Override
    public List<Suministro> obtenerSuministros() {
        List<Suministro> suministros = new ArrayList<Suministro>();
        try {
            Connection conn = ConnectionMySQL.getConnection();
            String sql = "select * from suministro join categoria c on suministro.idcategoria = c.idcategoria order by suministro.idsuministro;";
            Statement statement = conn.createStatement();
            ResultSet resultSet = statement.executeQuery(sql);
            while (resultSet.next()) {

                suministros.add(new Suministro(
                        resultSet.getInt(1),
                        new Categoria(resultSet.getInt(2), resultSet.getString(6)),
                        resultSet.getString(3),
                        resultSet.getFloat(4)
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
            CLogger.logErr(e.getMessage());
        }
        return suministros;
    }

    /**
     * Inserta un suministro nuevo a la base de datos
     * @param suministro suministro a ingresar.
     */
    @Override
    public void insertSuministro(Suministro suministro) {
        try {
            Connection conn = ConnectionMySQL.getConnection();
            String sql = "insert into suministro (idcategoria, nombre, precio) values (?, ?,?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, suministro.getCategoria().getIdCategoria());
            stmt.setString(2, suministro.getNombre());
            stmt.setFloat(3, suministro.getPrecio());
            int rows = stmt.executeUpdate();

            if (rows > 0) {
                JOptionPane.showMessageDialog(null, "Suministro Agregado correctamente");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            CLogger.logErr(e.getMessage());
        }
    }

    /**
     * Obtiene el ultimo suministro agregado
     * @return Suministro que se agrego de ultimas.
     */
    @Override
    public Suministro obtenerUltimoSuministro() {
        Suministro s = null;
        try {
            Connection conn = ConnectionMySQL.getConnection();
            String sql = "select * from suministro join categoria c on suministro.idcategoria = c.idcategoria order by idsuministro desc limit 1";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            rs.next();
            s = new Suministro(rs.getInt(1), new Categoria(rs.getInt(2), rs.getString(6)), rs.getString(3), rs.getFloat(4));

        } catch (SQLException e) {
            e.printStackTrace();
            CLogger.logErr(e.getMessage());
        }
        return s;
    }


}
