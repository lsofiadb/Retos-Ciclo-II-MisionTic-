package com.misiontic2022.reto5.view;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

import static javax.swing.WindowConstants.EXIT_ON_CLOSE;


/**
 * @author Cristian
 * @author Laura
 */
public class DialogEliminarSuministro extends JDialog {
    //atributos 
    JLabel lblEliminar, lblId;
    JTextField tId;
    JButton btnEliminar;
    
    //Constructor 
    public DialogEliminarSuministro(ActionListener listener){
        this.setModal(true);
        this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        this.setLayout(null);
        this.getContentPane().setBackground(new Color(204, 209, 209));
        this.setBounds(0, 0, 400, 280);
        this.setLocationRelativeTo(null);
        this.setResizable(false);
        crearComponentes(listener);
        this.setVisible(false);
    }
    
    public void crearComponentes(ActionListener listener) {
        lblEliminar = new JLabel("Eliminar Suministro");
        lblEliminar.setBounds(60, 10, 270, 30);
        lblEliminar.setForeground(Color.BLACK);
        lblEliminar.setFont(new Font("Times New Roman", 1, 25));
        add(lblEliminar);

        lblId = new JLabel("ID Suministro:");
        lblId.setBounds(20, 90, 220, 30);
        lblId.setForeground(Color.BLACK);
        lblId.setFont(new Font("Times New Roman", 1, 25));
        add(lblId);

        tId = new JTextField();
        tId.setBounds(200, 90, 150, 30);
        tId.setForeground(Color.BLACK);
        tId.setFont(new Font("Times New Roman", 1, 25));
        add(tId);

        btnEliminar = new JButton("Eliminar");
        btnEliminar.setBounds(85, 170, 220, 30);
        btnEliminar.setForeground(Color.BLACK);
        btnEliminar.setBackground(new Color(130, 224, 170));
        btnEliminar.setFont(new Font("Times New Roman", 1, 20));
        btnEliminar.addActionListener(listener);
        btnEliminar.setActionCommand("delSum");
        add(btnEliminar);

    }

    public void close(){
        tId.setText("");
        this.dispose();
    }

    public int getdata() {
        if (tId.getText().length() > 0)
            return Integer.parseInt(tId.getText());
        else JOptionPane.showMessageDialog(null,"Campo vacio o Id incorrecto","Error",JOptionPane.ERROR_MESSAGE);
        return -1;
    }
}
