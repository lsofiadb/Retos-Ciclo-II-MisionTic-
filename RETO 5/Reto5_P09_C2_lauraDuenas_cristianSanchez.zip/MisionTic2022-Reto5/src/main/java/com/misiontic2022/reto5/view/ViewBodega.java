package com.misiontic2022.reto5.view;

import com.misiontic2022.reto5.controller.StoreController;
import com.misiontic2022.reto5.model.Bodega;
import com.misiontic2022.reto5.model.Categoria;
import com.misiontic2022.reto5.model.Suministro;

import javax.swing.*;
import javax.swing.border.StrokeBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import static java.awt.GridBagConstraints.*;


/**
 * @author Cristian
 * @author Laura
 */
public class ViewBodega extends JFrame implements ActionListener {
    private JLabel lblTitle, lblBodega, lblProduct, lblCantidad, lblSuministro;

    private JTextField txtBodega;
    private JTextField txtProduct;
    private JTextField txtCantidad;

    private JButton btnAddSuministro;
    private JButton btnDeleteSuministro;
    private JButton btnEditBodega;

    private JScrollPane scpPane;
    private JTable tblSuministro;
    private TableModel tblModelSuministro;
    private DialogEliminarSuministro dialogEliminarSuministro;
    private DialogModificarBodega dialogModificarBodega;
    private DialogAgregarSuministro dialogAgregarSuministro;
    private DialogSelectAgregar dialogSelectAgregar;
    private DialogNuevoSuministro dialogNuevoSuministro;
    private Bodega bodega;

    public ViewBodega(Bodega bodega) {
        this.bodega = bodega;
        this.setTitle("Administrador de Inventario");
        this.setLayout(new GridBagLayout());
        initComponents();
        this.setSize(800, 700);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setResizable(false);
        this.getContentPane().setBackground(new Color(204, 209, 209));
        this.setVisible(true);
        dialogEliminarSuministro = new DialogEliminarSuministro(this);
        dialogModificarBodega = new DialogModificarBodega(bodega,this);
        dialogAgregarSuministro = new DialogAgregarSuministro(this);
        dialogSelectAgregar = new DialogSelectAgregar(this);
        dialogNuevoSuministro = new DialogNuevoSuministro(this);
    }

    public static void main(String[] args) {
        new ViewBodega(new Bodega());
    }

    private void initComponents() {
        lblTitle = new JLabel(bodega.getNombre());
        lblTitle.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 30));
        lblBodega = new JLabel("Id Bodega: ");
        lblProduct = new JLabel("Numero de Productos: ");
        lblCantidad = new JLabel("Cantidad de pisos: ");
        lblSuministro = new JLabel("Suministros");

        txtBodega = new JTextField();
        txtBodega.setEditable(false);
        txtBodega.setText(bodega.getIdbodega() + "");
        txtProduct = new JTextField();
        txtProduct.setEditable(false);
        txtProduct.setText(StoreController.obtenerTotalProductos(bodega) + "");
        txtCantidad = new JTextField();
        txtCantidad.setEditable(false);
        txtCantidad.setText(bodega.getCantidadpisos() + "");

        btnAddSuministro = new JButton("Añadir Suministro");
        btnAddSuministro.addActionListener(this);
        btnAddSuministro.setActionCommand("Add");
        btnAddSuministro.setBackground(new Color(130, 224, 170));
        btnDeleteSuministro = new JButton("Eliminar Suministro");
        btnDeleteSuministro.addActionListener(this);
        btnDeleteSuministro.setActionCommand("Remove");
        btnDeleteSuministro.setBackground(new Color(130, 224, 170));
        btnEditBodega = new JButton("Editar Bodega");
        btnEditBodega.addActionListener(this);
        btnEditBodega.setActionCommand("EditB");
        btnEditBodega.setBackground(new Color(130, 224, 170));

        scpPane = new JScrollPane();
        tblSuministro = new JTable();

        tblModelSuministro = new DefaultTableModel(new Object[]{"Id", "Nombre", "Categoria", "Precio"}, 0);
        updateModel(bodega);
        tblSuministro.setModel(tblModelSuministro);
        tblSuministro.setBackground(new Color(204, 209, 209));
        scpPane.setViewportView(tblSuministro);
        scpPane.setBackground(new Color(204, 209, 209));
        scpPane.getViewport().setBackground(new Color(204, 209, 209));
        scpPane.setViewportBorder(null);
        posicionateComponents();
    }

    private void posicionateComponents() {
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = REMAINDER;
//        gbc.fill = HORIZONTAL;
        gbc.anchor = CENTER;
        gbc.insets = new Insets(20, 10, 30, 10);
        add(lblTitle, gbc);
        gbc.anchor = WEST;
        gbc.fill = NONE;
        gbc.insets = new Insets(0, 5, 0, 5);
        gbc.gridwidth = 1;
        gbc.gridy++;
        gbc.gridx = 1;
        add(lblBodega, gbc);
        gbc.gridx++;
        gbc.ipadx = 60;
        gbc.fill = HORIZONTAL;
        add(txtBodega, gbc);
        gbc.fill = NONE;
        gbc.ipadx = 0;
        gbc.gridx++;
        add(lblProduct, gbc);
        gbc.gridx++;
        gbc.ipadx = 60;
        gbc.fill = HORIZONTAL;
        add(txtProduct, gbc);
        gbc.fill = NONE;
        gbc.ipadx = 0;
        gbc.gridx++;
        add(lblCantidad, gbc);
        gbc.gridx++;
        gbc.ipadx = 60;
        gbc.fill = NONE;
        add(txtCantidad, gbc);
        gbc.ipadx = 0;
        gbc.fill = HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy++;
        gbc.gridwidth = 8;
        gbc.insets = new Insets(40, 0, 5, 0);
        gbc.anchor = WEST;
        add(lblSuministro, gbc);
        gbc.anchor = CENTER;
        gbc.insets = new Insets(0, 0, 0, 0);
        gbc.gridwidth = 6;
        gbc.gridy++;
        gbc.gridheight = 5;
        add(scpPane, gbc);
        gbc.weighty = 0;
        gbc.gridheight = 1;
        gbc.gridwidth = 1;
        gbc.gridx = 6;
        gbc.insets = new Insets(100, 20, 0, 0);
        gbc.ipady = 10;
        gbc.ipadx = 30;
        add(btnAddSuministro, gbc);
        gbc.insets = new Insets(10, 20, 0, 0);
        gbc.gridy++;
        add(btnDeleteSuministro, gbc);
        gbc.gridy++;
        gbc.insets = new Insets(100, 20, 0, 0);
        add(btnEditBodega, gbc);
    }

    private void updateModel(Bodega bodega) {
        List<Suministro> suministros = StoreController.obtenerSuministrosBodega(bodega);
        Suministro[] data = suministros.toArray(new Suministro[0]);
        Object[][] matrixData = new Object[data.length][4];
        for (int i = 0; i < data.length; i++) {
            matrixData[i] = new Object[]{data[i].getIdSuministro(), data[i].getNombre(), data[i].getCategoria().getNombre(), data[i].getPrecio()};
        }
        tblModelSuministro = new DefaultTableModel(matrixData, new Object[]{"ID", "Nombre", "Categoría", "Precio"});
        tblSuministro.setModel(tblModelSuministro);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        switch (e.getActionCommand()) {
            case "Add":
                showAddSuministro();
                break;
            case "Remove":
                showDeleteSuministro();
                break;
            case "Edit":
                showEditSuministro();
                break;
            case "EditB":
                showEditBodega();
                break;
            case "new":
                showNewSuministro();
                break;
            case "exist":
                showExistSuministro();
                break;
            case "addNew":
                addNew();
                break;
            case "ExisSum":
                exist();
                break;
            case "delSum":
                del();
                break;
            case "editBod":
                editBod();
                break;
        }

    }

    private void editBod() {
        String nombre = dialogModificarBodega.getDataNombre();
        int numeroP = dialogModificarBodega.getDataNumeroP();
        if(nombre == null || numeroP == -1) return;
        dialogModificarBodega.close();
        bodega.setNombre(nombre);
        bodega.setCantidadpisos(numeroP);
        StoreController.updateBodega(bodega);
        updateModel(bodega);
        lblTitle.setText(bodega.getNombre());
        txtCantidad.setText(bodega.getCantidadpisos()+"");
    }

    private void del() {
        int id = dialogEliminarSuministro.getdata();
        if (id == -1) return;
        dialogEliminarSuministro.close();
        Suministro s = new Suministro(id);
        StoreController.deleteRegistro(s,bodega);
        updateModel(bodega);
        txtProduct.setText(String.valueOf(StoreController.obtenerTotalProductos(bodega)));
    }

    private void exist() {
        Suministro s = dialogAgregarSuministro.getSuministro();
        dialogAgregarSuministro.close();
        StoreController.newRegistro(bodega,s);
        updateModel(bodega);
        txtProduct.setText(String.valueOf(StoreController.obtenerTotalProductos(bodega)));
    }

    private void addNew() {
        Object[] data = dialogNuevoSuministro.getData();
        if(data == null) return;
        dialogNuevoSuministro.close();
        StoreController.insertNewInsumo((String) data[0], Float.parseFloat((String) data[1]), (Categoria) data[2]);
        StoreController.newRegistro(bodega,StoreController.obtenerUltimoSuministro());
        updateModel(bodega);
        txtProduct.setText(String.valueOf(StoreController.obtenerTotalProductos(bodega)));
    }

    private void showExistSuministro() {
        dialogSelectAgregar.setVisible(false);
        dialogAgregarSuministro.open();
    }

    private void showNewSuministro() {
        dialogSelectAgregar.setVisible(false);
        dialogNuevoSuministro.setVisible(true);
    }

    private void showEditBodega() {
        dialogModificarBodega.setVisible(true);
    }

    private void showEditSuministro() {

    }

    private void showDeleteSuministro() {
        dialogEliminarSuministro.setVisible(true);
    }

    private void showAddSuministro() {
        dialogSelectAgregar.setVisible(true);
    }
}
