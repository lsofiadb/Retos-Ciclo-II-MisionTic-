package com.misiontic2022.reto5.daoi;

import com.misiontic2022.reto5.model.Bodega;
import com.misiontic2022.reto5.model.Suministro;

import java.awt.event.ActionListener;
import java.util.ArrayList;

//Metodos a implementar para la tabla Almacenar

/**
 * Interface que se encarga de declarar los metodos de almacenar DAO.
 * @author Laura
 * @author Cristian
 */
public interface IAlmacenarDAO {
    /**
     * obtiene suministros de una bodega
     * @param bodega bodega donde buscar suministros
     * @return lista de suministros de una bodega
     */
    ArrayList<Suministro> obtenerSuministrosBodega(Bodega bodega);

    /**
     * Inserta suministro en bodega
     * @param suministro suministro a ingresar
     * @param bodega bodega donde se va a ingresar
     */
    void insertarRegistro(Suministro suministro, Bodega bodega);

    /**
     * Elimina suministro de bodega
     * @param suministro suministro a eliminar
     * @param bodega bodega donde se va a eliminar
     */
    void eliminarSuministro(Suministro suministro, Bodega bodega);

    /**
     * Obtener numero de productos que tiene relacionado una bodega
     * @param bodega bodega donde se contara los suministros
     * @return cantidad de suministros en la bodega.
     */
    int obtenerNumeroProductos(Bodega bodega);
}
