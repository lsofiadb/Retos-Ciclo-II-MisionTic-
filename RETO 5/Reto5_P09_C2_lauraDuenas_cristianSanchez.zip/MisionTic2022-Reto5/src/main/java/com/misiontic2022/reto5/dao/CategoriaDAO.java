package com.misiontic2022.reto5.dao;

import com.misiontic2022.reto5.connection.ConnectionMySQL;
import com.misiontic2022.reto5.daoi.ICategoriaDAO;
import com.misiontic2022.reto5.model.Categoria;
import com.misiontic2022.reto5.utils.CLogger;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 * Crud tabla Categoría
 * @author Laura
 * @author Cristian
 */
public class CategoriaDAO implements ICategoriaDAO {

    /**
     * Obtener todas las categorias de la tabla
     * @return Lista con todas las categorias de la Base de datos
     */
    @Override
    public List<Categoria> obtenerCategorias() {
        List<Categoria> categoria = new ArrayList<>();
        try {
            Connection conn = ConnectionMySQL.getConnection();
            String sql = "SELECT * from categoria;";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while(rs.next()) {
                categoria.add(new Categoria(
                   rs.getInt(1),
                   rs.getString(2)
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
            CLogger.logErr(e.getMessage());
        }
        return categoria;
    }
}
