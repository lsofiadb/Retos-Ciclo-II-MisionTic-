package com.misiontic2022.reto5.view;

import com.misiontic2022.reto5.controller.StoreController;
import com.misiontic2022.reto5.model.Bodega;
import com.misiontic2022.reto5.utils.CLogger;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


/**
 * @author Cristian
 * @author Laura
 */
public class PrincipalWindow extends JFrame implements ActionListener {
    private JLabel titleBodega;
    private JLabel lblBodega;
    private JComboBox<Bodega> cmbBodega;
    private JButton btnEnter;

    public PrincipalWindow() {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException e) {
            CLogger.logErr(e.getMessage());
        }
        this.setSize(320, 350);
        this.setLocationRelativeTo(null);
        this.setLayout(new GridBagLayout());
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setTitle("Seleccionar Bodega");
        this.setResizable(false);
        initComponents();
        this.setVisible(true);
    }

        private void initComponents() {
        titleBodega = new JLabel("Control de Inventario");
        titleBodega.setFont(new Font(titleBodega.getFont().getFontName(), Font.BOLD, 25));
        lblBodega = new JLabel("Elija una bodega para administrar");
        lblBodega.setFont(new Font(titleBodega.getFont().getFontName(), Font.PLAIN, 15));
        cmbBodega = new JComboBox<>(new DefaultComboBoxModel<>(StoreController.obtenerBodegas() != null ? StoreController.obtenerBodegas() : new Bodega[0]));
        btnEnter = new JButton("Entrar");
        btnEnter.addActionListener(this);
        posicionateComponents();
    }

    private void posicionateComponents() {
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new Insets(20, 10, 50, 10);
        gbc.anchor = GridBagConstraints.BASELINE;
        add(titleBodega, gbc);
        gbc.insets = new Insets(20, 10, 5, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.gridy++;
        add(lblBodega, gbc);
        gbc.gridy++;
        gbc.ipady = 5;
        gbc.insets = new Insets(0, 10, 10, 10);
        add(cmbBodega, gbc);
        gbc.weighty = .1;
        gbc.fill = GridBagConstraints.NONE;
        gbc.gridy++;
        gbc.ipady = 15;
        gbc.ipadx = 35;
        gbc.insets = new Insets(10, 10, 10, 10);
        add(btnEnter, gbc);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Bodega b = (Bodega) cmbBodega.getSelectedItem();
        new ViewBodega(b);
        this.dispose();
    }

    public static void main(String[] args) {
        new PrincipalWindow();
    }
}
