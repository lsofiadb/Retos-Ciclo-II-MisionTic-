package com.misiontic2022.reto5.model;


/**
 * Clase POJO Proveedor
 * @author Cristian
 * @author Laura
 */
public class Proveedor {
    private int idProveedor;
    private boolean esActivo;
    private String nombre;

    public Proveedor() {
        idProveedor = 0;
        esActivo = false;
        nombre = null;
    }

    public Proveedor(int idProveedor, boolean esActivo, String nombre) {
        this.idProveedor = idProveedor;
        this.esActivo = esActivo;
        this.nombre = nombre;
    }

    public int getIdProveedor() {
        return idProveedor;
    }

    public void setIdProveedor(int idProveedor) {
        this.idProveedor = idProveedor;
    }

    public boolean isEsActivo() {
        return esActivo;
    }

    public void setEsActivo(boolean esActivo) {
        this.esActivo = esActivo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
}
