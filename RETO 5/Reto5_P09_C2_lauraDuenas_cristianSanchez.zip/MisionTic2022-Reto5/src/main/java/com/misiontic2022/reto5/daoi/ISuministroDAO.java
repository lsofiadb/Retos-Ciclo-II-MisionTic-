package com.misiontic2022.reto5.daoi;

import com.misiontic2022.reto5.dao.SuministroDAO;
import com.misiontic2022.reto5.model.Suministro;

import java.util.List;

/**
 * Interface para implementar <code>SuministroDAO</code>
 * @see SuministroDAO
 * @author Laura
 * @author Cristian
 */
public interface ISuministroDAO {

    /**
     * Actualiza datos de un suministro
     * @apiNote No es usado
     * @param suministro suministro a actualizar
     */
    void actualizarSuministro(Suministro suministro);

    /**
     * Obtener todos los suministros
     * @return lista con todos los suministros
     */
    List<Suministro> obtenerSuministros();

    /**
     * Inserta un nuevo suministro en la tabla Suministro
     * @param suministro suministro a ingresar
     */
    void insertSuministro(Suministro suministro);

    /**
     * Obtiene ultimo suministro ingresado
     * @return El ultimo suministro ingresado
     */
    Suministro obtenerUltimoSuministro();
}
