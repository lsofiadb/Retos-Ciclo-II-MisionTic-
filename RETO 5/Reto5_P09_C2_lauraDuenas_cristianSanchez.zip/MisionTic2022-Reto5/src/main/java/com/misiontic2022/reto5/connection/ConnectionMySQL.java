package com.misiontic2022.reto5.connection;

import com.misiontic2022.reto5.utils.CLogger;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;

import static com.misiontic2022.reto5.utils.ConstantProperties.*;

public class ConnectionMySQL {
    private static Connection conn;

    /**
     * Obtiene la conexión a la base de datos para usar una sola conexión.
     *
     * @return Objeto <code>Connection</code> con conexión con la base de datos mysql.
     * @throws SQLException if a database access error occurs, this method
     *                      is called on a closed connection
     *                      or the given parameters are not <code>ResultSet</code>
     *                      constants indicating type and concurrency
     */
    public static Connection getConnection() throws SQLException {

        if (conn == null) {

            conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            CLogger.log(Level.INFO, "DataBase-Connected");
        }
        return conn;
    }
}
