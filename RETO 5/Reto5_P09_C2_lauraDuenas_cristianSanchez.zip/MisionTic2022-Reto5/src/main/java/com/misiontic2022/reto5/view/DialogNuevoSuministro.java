package com.misiontic2022.reto5.view;

import com.misiontic2022.reto5.controller.StoreController;
import com.misiontic2022.reto5.model.Categoria;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionListener;
import javax.swing.*;


/**
 * @author Cristian
 * @author Laura
 */
public class DialogNuevoSuministro extends JDialog {
    //atributos
    JLabel title, lblNombre, lblPrecio, lblCategoria;
    JTextField tNombre, tPrecio;
    JComboBox<Categoria> cmbCategoria;
    JButton btnAdd;

    //Constructor
    public DialogNuevoSuministro(ActionListener listener) {
        this.setModal(true);
        this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        this.setLayout(null);
        this.getContentPane().setBackground(new Color(204, 209, 209));
        this.setBounds(0, 0, 400, 350);
        this.setLocationRelativeTo(null);
        this.setResizable(false);

        crearComponentes(listener);
        this.setVisible(false);
    }

    public void crearComponentes(ActionListener listener) {
        title = new JLabel("Nuevo suministro");
        title.setBounds(60, 10, 270, 30);
        title.setForeground(Color.BLACK);
        title.setFont(new Font("Times New Roman", 1, 25));
        add(title);

        lblNombre = new JLabel("Nombre: ");
        lblNombre.setBounds(20, 90, 220, 30);
        lblNombre.setForeground(Color.BLACK);
        lblNombre.setFont(new Font("Times New Roman", 1, 25));
        add(lblNombre);

        tNombre = new JTextField();
        tNombre.setBounds(200, 90, 150, 30);
        tNombre.setForeground(Color.BLACK);
        tNombre.setFont(new Font("Times New Roman", 1, 25));
        add(tNombre);

        lblPrecio = new JLabel("Precio: ");
        lblPrecio.setBounds(20, 140, 220, 30);
        lblPrecio.setForeground(Color.BLACK);
        lblPrecio.setFont(new Font("Times New Roman", 1, 25));
        add(lblPrecio);

        tPrecio = new JTextField();
        tPrecio.setBounds(200, 140, 150, 30);
        tPrecio.setForeground(Color.BLACK);
        tPrecio.setFont(new Font("Times New Roman", 1, 25));
        add(tPrecio);

        lblCategoria = new JLabel("Categoria: ");
        lblCategoria.setBounds(20, 190, 220, 30);
        lblCategoria.setForeground(Color.BLACK);
        lblCategoria.setFont(new Font("Times New Roman", 1, 25));
        add(lblCategoria);

        cmbCategoria = new JComboBox<>();
        cmbCategoria.setBounds(200, 190, 150, 30);
        cmbCategoria.setForeground(Color.BLACK);
        cmbCategoria.setFont(new Font("Times New Roman", 1, 25));
        add(cmbCategoria);

        btnAdd = new JButton("Agregar");
        btnAdd.setBounds(85, 240, 220, 30);
        btnAdd.setForeground(Color.BLACK);
        btnAdd.setBackground(new Color(130, 224, 170));
        btnAdd.setFont(new Font("Times New Roman", 1, 20));
        btnAdd.addActionListener(listener);
        btnAdd.setActionCommand("addNew");
        add(btnAdd);

        updateComboBox();
    }

    private void updateComboBox() {
        cmbCategoria.removeAllItems();
        for (Categoria categoria : StoreController.obtenerTodoCategoria()) {
            cmbCategoria.addItem(categoria);
        }
    }

    public Object[] getData() {
        updateComboBox();
        String nombre = tNombre.getText();
        String precio = tPrecio.getText();
        if (nombre.length() > 0 && precio.length() > 0 && precio.matches("^[\\d.]+$"))
            return new Object[]{nombre, precio, cmbCategoria.getSelectedItem()};
        JOptionPane.showMessageDialog(this, "Campos vacios o Con formatos incorrectos", "Error", JOptionPane.ERROR_MESSAGE);
        return null;
    }

    public void close() {
        tPrecio.setText("");
        tNombre.setText("");
        this.dispose();
    }
}
