package com.misiontic2022.reto5.utils;

/**
 * @author Cristian
 * @author Laura
 */
public class ConstantProperties {
    public final static String DB_URL = "jdbc:mysql://localhost:3306/rigo_tiendas";
    public final static String USERNAME = "root";
    public final static String PASSWORD = "reto5";
}
