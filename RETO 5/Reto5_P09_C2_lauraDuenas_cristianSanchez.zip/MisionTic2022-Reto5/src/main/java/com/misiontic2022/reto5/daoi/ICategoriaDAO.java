package com.misiontic2022.reto5.daoi;

import com.misiontic2022.reto5.model.Categoria;

import java.util.List;

/**
 * Interface de <code>CategoriaDAO</code>
 * @author Laura
 * @author Cristian
 */
public interface ICategoriaDAO {
    /**
     * Obtiene todas las categorias de la base de datos
     * @return Lista con todas las categorias del sistema
     */
    List<Categoria> obtenerCategorias();
}
