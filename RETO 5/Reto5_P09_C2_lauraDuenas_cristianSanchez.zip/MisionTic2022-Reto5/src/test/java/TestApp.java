import com.misiontic2022.reto5.connection.ConnectionMySQL;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class TestApp {
    public static void main(String[] args) {
        try {
            Connection conn = ConnectionMySQL.getConnection();
        } catch (SQLException e) {
            Logger.getGlobal().log(Level.WARNING,e.getMessage());
        }
    }
}
