CREATE schema rigo_tiendas;
use rigo_tiendas;

create table IF NOT exists bodega(
    idbodega      int         NOT NULL  primary key auto_increment,
    nombre        varchar(30) not null,
    cantidadpisos int         not null
);
create table IF NOT exists categoria
(
    idcategoria int         not null primary key auto_increment,
    nombre      varchar(30) not null
);
create table IF NOT exists proveedor
(
    idproveedor int         not null primary key auto_increment,
    esactivo    varchar(2)     not null,
    nombre      varchar(45) not null
);
create table IF NOT exists suministro
(
    idsuministro int         not null primary key auto_increment,
    idcategoria  int         not null,
    nombre       varchar(30) not null,
    precio       float       not null,
    foreign key (idcategoria) REFERENCES categoria (idcategoria)
);
create table IF NOT exists cotizacion
(
    idcotizacion int  not null primary key unique auto_increment,
    fecha        DATETIME not null,
    idsuministro int  not null,
    idproveedor  int  not null,
    foreign key (idsuministro) REFERENCES suministro (idsuministro),
    foreign key (idproveedor) REFERENCES proveedor (idproveedor)
);
create table if not exists almacenar
(
    idsuministro int not null,
    idbodega     int not null,
    foreign key (idsuministro) REFERENCES suministro (idsuministro),
    foreign key (idbodega) REFERENCES bodega (idbodega)
);

-- Inserts BODEGA
insert into bodega (idbodega, nombre, cantidadpisos)
values (1, 'Bodega norte', 1),
       (2, 'Bodega timiza', 4),
       (3, 'Zona Industrial', 2),
       (4, 'Zona franca', 6);

-- Inserts CATEGORÍA
insert into categoria (idcategoria, nombre)
values (1,'Hogar');
insert into categoria (idcategoria,nombre)
values (2, 'Oficina');
insert into categoria (idcategoria,nombre)
values (3,'Juguetería');
insert into categoria (idcategoria,nombre)
values (4,'Papelería');

-- Inserts PROVEEDOR
insert into proveedor (idproveedor, esactivo, nombre)
values (1, 'si', 'Juguetes Marcopolo'),
       (2, 'si', 'Panamericana'),
       (3, 'no', 'Electrocentro'),
       (4, 'si', 'Toy mercas'),
       (5, 'si', 'Distribuidora Golden'),
       (6, 'si', 'Compra hogar');

-- Inserts SUMINISTRO
insert into suministro (idsuministro, idcategoria, nombre, precio)
values (1,(select idcategoria from categoria where nombre = 'Juguetería'), 'Balón Golty profesional', 85000);
insert into suministro (idsuministro,idcategoria, nombre, precio)
values (2,(select idcategoria from categoria where nombre = 'Papelería'),'Borradores x 12 und',12200);
insert into suministro (idsuministro,idcategoria, nombre, precio)
values (3,(select idcategoria from categoria where nombre = 'Hogar'),'Cubrelecho King',130000);
insert into suministro (idsuministro,idcategoria, nombre, precio)
values (4,(select idcategoria from categoria where nombre = 'Oficina'),'impresora',550300);
insert into suministro (idsuministro,idcategoria, nombre, precio)
values (5,(select idcategoria from categoria where nombre = 'Hogar'),'Lampara',90000);
insert into suministro (idsuministro,idcategoria, nombre, precio)
values (6,(select idcategoria from categoria where nombre = 'Papelería'),'Marcador colores x 12 und',18700);
insert into suministro (idsuministro,idcategoria, nombre, precio)
values (7,(select idcategoria from categoria where nombre = 'Juguetería'),'XBox',580000);
insert into suministro (idsuministro,idcategoria, nombre, precio)
values (8,(select idcategoria from categoria where nombre = 'Juguetería'),'Pista de carros importada',320000);
insert into suministro (idsuministro,idcategoria, nombre, precio)
values (9,(select idcategoria from categoria where nombre = 'Papelería'),'Resma papel carta',12000);
insert into suministro (idsuministro,idcategoria, nombre, precio)
values (10,(select idcategoria from categoria where nombre = 'Oficina'),'Teléfono inalámbrico',275000);

-- Inserts COTIZACIÓN
insert into cotizacion (idcotizacion, fecha, idsuministro, idproveedor)
values (1, date('2020-11-19 00:00:00'),
        (select idsuministro from suministro where suministro.nombre = 'Lampara'),
        (select idproveedor from proveedor where proveedor.nombre = 'Juguetes Marcopolo')),
       (2, date('2021-06-01  00:00:00'),
        (select idsuministro from suministro where nombre = 'impresora'),
        (select idproveedor from proveedor where nombre = 'Electrocentro')),
       (3, date('2021-02-10  00:00:00'),
        (select idsuministro from suministro where nombre = 'Teléfono inalámbrico'),
        (select idproveedor from proveedor where nombre = 'Compra hogar')),
       (4, date('2018-07-12  00:00:00'),
        (select idsuministro from suministro where nombre = 'Pista de carros importada'),
        (select idproveedor from proveedor where nombre = 'Distribuidora Golden')),
       (5, date('2021-12-01  00:00:00'),
        (select idsuministro from suministro where nombre = 'Cubrelecho King'),
        (select idproveedor from proveedor where nombre = 'Toy mercas')),
       (6, date('2021-03-20  00:00:00'),
        (select idsuministro from suministro where nombre = 'Resma papel carta'),
        (select idproveedor from proveedor where nombre = 'Juguetes Marcopolo')),
       (7, date('2021-04-28  00:00:00'),
        (select idsuministro from suministro where nombre = 'Balón Golty profesional'),
        (select idproveedor from proveedor where nombre = 'Juguetes Marcopolo')),
       (8, date('2019-06-15  00:00:00'),
        (select idsuministro from suministro where nombre = 'XBox'),
        (select idproveedor from proveedor where nombre = 'Toy mercas')),
       (9, date('2020-07-11  00:00:00'),
        (select idsuministro from suministro where nombre = 'Borradores x 12 und'),
        (select idproveedor from proveedor where nombre = 'Panamericana')),
       (10, date('2021-09-19  00:00:00'),
        (select idsuministro from suministro where nombre = 'Marcador colores x 12 und'),
        (select idproveedor from proveedor where nombre = 'Panamericana')),
       (11, date('2019-08-21  00:00:00'),
        (select idsuministro from suministro where nombre = 'Lampara'),
        (select idproveedor from proveedor where nombre = 'Distribuidora Golden')),
       (12, date('2021-08-18  00:00:00'),
        (select idsuministro from suministro where nombre = 'Cubrelecho King'),
        (select idproveedor from proveedor where nombre = 'Toy mercas'));

-- Inserts ALMACENAR
insert into almacenar (idsuministro, idbodega)
values ((select idsuministro from suministro where nombre = 'XBox'),
        (select idbodega from bodega where nombre = 'Bodega norte')),
       ((select idsuministro from suministro where nombre = 'Balón Golty profesional'),
        (select idbodega from bodega where nombre = 'Bodega norte')),
       ((select idsuministro from suministro where nombre = 'Pista de carros importada'),
        (select idbodega from bodega where nombre = 'Zona franca')),
       ((select idsuministro from suministro where nombre = 'Lampara'),
        (select idbodega from bodega where nombre = 'Bodega timiza')),
       ((select idsuministro from suministro where nombre = 'Lampara'),
        (select idbodega from bodega where nombre = 'Bodega timiza')),
       ((select idsuministro from suministro where nombre = 'Teléfono inalámbrico'),
        (select idbodega from bodega where nombre = 'Bodega norte')),
       ((select idsuministro from suministro where nombre = 'Resma papel carta'),
        (select idbodega from bodega where nombre = 'Bodega norte')),
       ((select idsuministro from suministro where nombre = 'Marcador colores x 12 und'),
        (select idbodega from bodega where nombre = 'Zona Industrial')),
       ((select idsuministro from suministro where nombre = 'Cubrelecho King'),
        (select idbodega from bodega where nombre = 'Zona Industrial')),
       ((select idsuministro from suministro where nombre = 'Balón Golty profesional'),
        (select idbodega from bodega where nombre = 'Zona Industrial')),
       ((select idsuministro from suministro where nombre = 'Borradores x 12 und'),
        (select idbodega from bodega where nombre = 'Zona franca')),
       ((select idsuministro from suministro where nombre = 'XBox'),
        (select idbodega from bodega where nombre = 'Zona franca')),
       ((select idsuministro from suministro where nombre = 'Teléfono inalámbrico'),
        (select idbodega from bodega where nombre = 'Zona franca')),
       ((select idsuministro from suministro where nombre = 'Cubrelecho King'),
        (select idbodega from bodega where nombre = 'Zona franca')),
       ((select idsuministro from suministro where nombre = 'impresora'),
        (select idbodega from bodega where nombre = 'Zona franca'));

update suministro
set precio = 122300
where nombre = 'Lampara';

update suministro
set idcategoria = (select categoria.idcategoria from categoria where categoria.nombre = 'Hogar')
where nombre = 'XBox';

update almacenar
set idbodega = (select idbodega from bodega where nombre = 'Bodega timiza')
where (select nombre from suministro where suministro.idsuministro = almacenar.idsuministro) = 'Balón Golty profesional';

delete
from cotizacion
where idproveedor = (select idproveedor from proveedor where nombre = 'Juguetes Marcopolo');